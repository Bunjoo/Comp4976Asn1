namespace OptionsWebSite.Migrations.DiplomaOptionsMigrations
{
    using System;
    using System.Data.Entity.Migrations;
    
    public partial class SeedChoices : DbMigration
    {
        public override void Up()
        {
        }
        
        public override void Down()
        {
        }
    }
}
